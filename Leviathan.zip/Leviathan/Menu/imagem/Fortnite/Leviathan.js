// homepage.js (dentro da pasta 'java')

document.addEventListener('DOMContentLoaded', () => {
    // ----------------------------------------------------
    // Código para o CARROSSEL DE IMAGENS
    // ----------------------------------------------------
    const mainGameImage = document.getElementById('mainGameImage');
    const thumbnails = document.querySelectorAll('.thumbnail');
    const leftArrow = document.querySelector('.left-arrow');
    const rightArrow = document.querySelector('.right-arrow');

    let currentIndex = 0;

    function updateCarousel(newIndex) {
        if (thumbnails[currentIndex]) {
            thumbnails[currentIndex].classList.remove('active');
        }

        currentIndex = newIndex;
        if (currentIndex < 0) {
            currentIndex = thumbnails.length - 1;
        } else if (currentIndex >= thumbnails.length) {
            currentIndex = 0;
        }

        if (thumbnails[currentIndex]) {
            thumbnails[currentIndex].classList.add('active');
        }

        const newImageFileName = thumbnails[currentIndex].dataset.image;
        // Caminho para a pasta 'imagensFortnite'
        mainGameImage.src = `imagensFortnite/${newImageFileName}`;
    }

    thumbnails.forEach((thumbnail, index) => {
        thumbnail.addEventListener('click', () => {
            updateCarousel(index);
        });
    });

    leftArrow.addEventListener('click', () => {
        updateCarousel(currentIndex - 1);
    });

    rightArrow.addEventListener('click', () => {
        updateCarousel(currentIndex + 1);
    });

    // ----------------------------------------------------
    // CÓDIGO PARA A FUNCIONALIDADE DAS ABAS (Visão Geral / Gêneros)
    // ----------------------------------------------------
    const gameTabs = document.querySelectorAll('.game-tabs .tab-item');
    // Seleciona os divs de conteúdo das abas (que têm a classe .tab-content)
    const allTabContents = document.querySelectorAll('.tab-content-container > .tab-content'); 

    gameTabs.forEach(tab => {
        tab.addEventListener('click', (event) => {
            event.preventDefault();

            // 1. Remove a classe 'active' de TODAS as abas
            gameTabs.forEach(t => t.classList.remove('active'));
            // 2. Adiciona a classe 'active' à aba clicada
            event.currentTarget.classList.add('active');

            // 3. Esconde TODOS os conteúdos de aba
            allTabContents.forEach(content => {
                content.classList.remove('active');
            });

            // 4. Pega o valor do 'data-tab' da aba clicada
            const targetTab = event.currentTarget.dataset.tab;
            let targetContentId;

            if (targetTab === 'overview') {
                targetContentId = 'overview-wrapper'; // O ID do div que contém carrossel + texto
            } else if (targetTab === 'genres') {
                targetContentId = 'genres-content'; // O ID do div de gêneros
            }
            
            // 5. Encontra o conteúdo alvo e o torna visível
            const activeContent = document.getElementById(targetContentId);
            if (activeContent) {
                activeContent.classList.add('active');
                console.log(`Aba "${event.currentTarget.textContent}" clicada! Conteúdo de "${targetContentId}" exibido.`);

                // Se a aba Visão Geral foi clicada, inicializa ou reinicializa o carrossel
                if (targetTab === 'overview') {
                    updateCarousel(0); // Reinicia o carrossel ao mostrar a Visão Geral
                }
            }
        });
    });

    // Ao carregar a página, ativa a aba "Visão Geral" e exibe seu conteúdo
    const initialOverviewTab = document.querySelector('.tab-item[data-tab="overview"]');
    if (initialOverviewTab) {
        initialOverviewTab.classList.add('active');
        document.getElementById('overview-wrapper').classList.add('active');
        updateCarousel(0); // Garante que o carrossel esteja visível e iniciado
    }
});